import React from 'react';

class Footbar extends React.Component {
    constructor(props) {
        super(props)
        }

    render() {
        return (
            <footer>
                <p>Copyright &copy; 2020 | Picnique Pastry Co.</p>
            </footer>
        )
    }
}

export default Footbar