import React from 'react';
import { Badge, Button } from 'react-bootstrap';
import CostItem from '../Components/CostItem';

class VariableCost extends React.Component {
    constructor(props) {
        super(props)
        this.addIngredient = props.addIngredient
        this.deleteIngredient = props.deleteIngredient
    }

    render() {
                return (
            <React.Fragment>
                 <div className="cost-label row"
                    style={{marginTop: "10px"}}
                >
                    <div className="col-11">
                        <div className="row" style={{fontSize: "20px"}}>
                            <div className="col-3"
                                style={{paddingLeft: "75px"}}
                            >
                                <Badge pill 
                                    style={{
                                        backgroundColor: "rgb(247, 230, 182)",
                                        padding: "10px 20px 10px 20px"
                                    }}>
                                    Variable Cost
                                </Badge>
                            </div>
                            <div className="col-6">
                                <span style={{marginRight:"10px"}}>Amount of piece/tray:</span>
                                <input></input>
                            </div>
                        </div>
                    </div>
                    <div className="col-1">
                        <Button variant="info" onClick={this.addIngredient}> Add</Button>
                    </div>
                </div>
                <div className="cost-list"
                    style={{minHeight: "600px"}}
                >
                    {this.props.variableCost.map( (data) => <CostItem img={data.img} name={data.name} onClickDelete={() => this.deleteIngredient(data.name)}/>)}
                </div>
            </React.Fragment>
        )
    }
}

export default VariableCost;