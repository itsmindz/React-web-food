import React from 'react';
import { Button } from 'react-bootstrap';

class PlusButton extends React.Component {
    constructor(props) {
        super(props)
        this.onClick = props.action
    }

    render () {
        return (
            <div style={{
                width: "250px",
                height: "250px",
                backgroundColor: "white",
                display: "inline-block",
                borderRadius: "50%"
            }}>
            <Button variant="outline-dark"
                className="align-middle"
              style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: "50%",
                  verticalAlign: "middle",
                  lineHeight: "0%"
              }} onClick={this.onClick}
              > <span className="align-middle" style={{fontSize: "12em"}}> + </span></Button>
            </div>
        )
    }
}

export default PlusButton