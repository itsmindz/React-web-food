import React from 'react';
import { Badge } from 'react-bootstrap';


class MenuItem extends React.Component {
    constructor(props) {
        super(props)
        this.id = props.id
        this.img = props.img;
        this.name = props.name;
    }

    render () {
        return (
            <a href={`/cost/${this.id}`}>
                <div 
                    style={{
                        height: "250px",
                        width: "250px",
                        display: "inline-block",
                        margin: "10px",
                        padding: "5px",
                        textAlign: "center",
                        backgroundColor: "RGB(247, 247, 228,0.3)",
                        borderWidth: "2px",
                        color: "black"
                    }}
                >
                    <img src={this.img} 
                        style={{
                            width: "80%",
                            height: "80%",
                            borderRadius: "50%"
                        }}
                        alt="Avatar"/>
                    <Badge
                        pill 
                        style={{
                            backgroundColor: "rgb(255, 190, 152, 0.5)",
                            paddingTop: "10px",
                            paddingBottom: "10px"
                        }}
                    > 
                        {this.name} 
                    </Badge>
                </div>
            </a>
        )
    }
}

export default MenuItem