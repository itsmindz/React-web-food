import React from 'react';
import { Badge, Button, ButtonGroup } from 'react-bootstrap';

class TotalCost extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <React.Fragment>
                 <div className="row"
                    style={{margin: "10px",
                    fontSize: "25px",
                    textAlign: "center"
                        }}
                 >
                   <span style={{margin:"0 auto"}}> Total Cost: 
                   <Badge className={"blankBadge"}> {this.props.TotalCost} </Badge>
                   </span>
                </div>
                <div className="row"
                    style={{
                        margin: "10px",
                        fontSize: "25px",
                        textAlign: "center"
                    }}>
                    <span style={{margin:"0 auto"}}> Margin: 
                        <ButtonGroup   ButtonGroup aria-label="Basic example" style={{margin:"0 auto"}}>
                                <Button variant="secondary" value={30}>30%</Button>
                                <Button variant="secondary" value={50}>50%</Button>
                                <Button variant="secondary" value={80}>80%</Button>
                                <Button variant="secondary" value={100}>100%</Button>
                                <Button variant="secondary" value={150}>150%</Button>
                            </ButtonGroup>
                   </span>
                </div>
                <div className="row"
                    style={{
                        margin: "10px",
                        fontSize: "25px",
                        textAlign: "center"
                        }}>
                    <span style={{margin:"0 auto"}}> Total Price: 
                        <Badge className={"blankBadge"}> {this.props.TotalCost} </Badge>
                   </span>
                </div>
            </React.Fragment>
        )
    }
}

export default TotalCost;