import React from 'react';

class Navbar extends React.Component {
    constructor(props) {
        super(props)
        }

    render() {
        return (
            <div className="menubar">
                <div className="container">
                    <div className="logo">
                        <h1>PICNIQUE PASTRY</h1>
                    </div>
                    <ul className="menu">
                        <li>
                            <a href="/">Home</a>
                        </li>
                        <li>
                            <a href="/menu">Menu</a>
                        </li>
                        <li>
                            <a href="/login">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        )
    }
}

export default Navbar