import React from 'react';

class LoginForm extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      email: '',
      password: '',
      currentUser: null,
      message: ''
    }
  }

  onChange = e => {
    const { name, value } = e.target

    this.setState({
      [name]: value
    })
  }

  onSubmit = e => {
    e.preventDefault()

    const { email, password } = this.state
    // TODO: implement signInWithEmailAndPassword()
  }

  render() {
    return (
      <div class="login-form">
        <h1>Login</h1>
        <form action = "auth" method= "post">
            <input type ="text" name="username" placeholder="Username" required/>
            <input type="password" name="password" placeholder="Password" required/>
            <input type="submit"/>
            <p>Not yet a member?<a href="/">Sign Up</a></p>
        </form>
    </div>
    )
  }
}

export default LoginForm;