import React from 'react';
import { Badge, Button, ButtonGroup } from 'react-bootstrap';

class FixedCost extends React.Component {
    constructor(props) {
        super(props)
        this.utilityPic = "https://media.angieslist.com/styles/widescreen_large/s3/s3fs-public/ax175_7335_9.jpg?itok=Lq_AalBH";
        this.wagePic = "https://www.worklawyers.com/wp-content/uploads/waiting-time-penalty-california-final-wages.svg"
    }

    render() {
        return (
            <React.Fragment>
                 <div className="cost-label row"
                    style={{marginTop: "10px"
                        }}
                 >
                    <div className="col-11" style={{paddingLeft: "75px",fontSize: "20px"}}>
                        <Badge pill 
                            style={{
                                backgroundColor: "rgb(247, 230, 182)",
                                padding: "10px 20px 10px 20px"
                            }}>
                            Fixed Cost
                        </Badge>
                    </div>
                </div>
                <div className="row">
                    <div className="col-2"></div>
                    <div className="col-4 justify-content-center fixed-box">
                        <div className="row">
                            <Badge pill 
                                style={{
                                    backgroundColor: "rgb(255, 190, 152, 0.5)",
                                    padding: "10px 20px 10px 20px",
                                    margin:"0 auto"
                                }}>
                                Utility Cost
                            </Badge>
                        </div>
                        <div className="row fixed-pic">
                            <img src={this.utilityPic}
                                style={{
                                    objectFit: "cover",
                                    height: "300px",
                                    width: "300px",
                                    borderRadius: "50%",
                                    margin:"0 auto"
                                }}
                            />
                        </div>
                        <div className="row">
                            <ButtonGroup aria-label="Basic example" style={{margin:"0 auto"}}>
                                <Button variant="secondary" value={30}>30%</Button>
                                <Button variant="secondary" value={40}>40%</Button>
                                <Button variant="secondary" value={50}>50%</Button>
                            </ButtonGroup>
                        </div>
                    </div>
                    <div className="col-4 justify-content-center fixed-box">
                        <div className="row">
                            <Badge pill 
                                style={{
                                    backgroundColor: "rgb(255, 190, 152, 0.5)",
                                    padding: "10px 20px 10px 20px",
                                    margin:"0 auto"
                                }}>
                                Employee Wage
                            </Badge>
                        </div>
                        <div className="row fixed-pic">
                            <img src={this.wagePic}
                                style={{
                                    objectFit: "cover",
                                    height: "300px",
                                    width: "300px",
                                    borderRadius: "50%",
                                    margin:"0 auto"
                                }}
                            />
                        </div>
                        <div className="row">
                             <span style={{margin:"0 auto"}}>
                                <span style={{margin:"auto"}}>Price</span>
                                <input style={{marginLeft: "10px", width:"150px"}}></input>
                            </span>
                        </div>
                    </div>
                    <div className="col-2"></div>
                </div>
            </React.Fragment>
        )
    }
}

export default FixedCost;