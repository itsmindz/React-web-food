import React from 'react';
import { Badge, Button } from 'react-bootstrap';



class CostItem extends React.Component {
    constructor(props) {
        super(props)
        this.name = props.name;
        this.img = props.img;
        this.onClickDelete = props.onClickDelete
    }

    render () {
        return (
            <div 
                style={{
                    height: "250px",
                    width: "250px",
                    display: "inline-block",
                    margin: "10px",
                    padding: "10px",
                    textAlign: "center",
                    backgroundColor: "RGB(247, 247, 228)",
                    borderWidth: "2px",
                    color: "black"
                }}
            >
                <div className="row">
                    <div className="col-10" style={{paddingLeft:"4px"}}>
                    <Badge
                        pill
                        style={{
                            backgroundColor: "rgb(255, 190, 152, 0.5)",
                            padding: "5px 20px 5px 20px",
                            marginBottom: "2px"
                        }}
                    > {this.name.startsWith("empty-") ? <input></input> : this.name} 
                    </Badge>
                    </div>
                    <div className="col-1" style={{width:"2px"}}>
                        <Button variant="danger" onClick={this.onClickDelete}>x</Button>
                    </div>
                </div>
                <img src={this.img} 
                    style={{
                        objectFit: "cover",
                        width: "80%",
                        height: "50%",
                        borderRadius: "20%"
                    }}/>
                <div>
                    <span style={{marginRight:"10px"}}>Price</span>
                    <input style={{width:"150px"}}></input>
                </div>
                <div>
                    <span style={{marginRight:"10px"}}>Total (g)</span>
                    <input style={{width:"150px"}}></input>
                </div>
                <div>
                    <span style={{marginRight:"10px"}}>Used (g)</span>
                    <input style={{width:"150px"}}></input>
                </div>
                
            </div>
        )
    }
}

export default CostItem