import React from 'react';
import Navbar from '../Components/Navbar';
import Footbar from '../Components/Footbar';
import VariableCost from '../Components/VariableCost';
import FixedCost from '../Components/FixedCost';
import TotalCost from '../Components/TotalCost';


const defaultVariableCost = [
    {name:"Egg", img:"https://ichef.bbci.co.uk/news/1024/cpsprodpb/7614/production/_105482203__105172250_gettyimages-857294664.jpg"},
    {name:"Flour", img:"https://cdn11.bigcommerce.com/s-dis4vxtxtc/images/stencil/1280x1280/products/2134/3135/image_1602__13331.1567254938.jpg?c=2?imbypass=on"},
    {name:"Butter", img:"https://dairyfarmersofcanada.ca/sites/default/files/product_butter_thumb.jpg"},
    {name:"Chocolate", img:"https://cdn.shopify.com/s/files/1/0808/8861/products/Milk_78a0ed4b-fe94-4156-a79f-6a8fb148fd79_grande.jpg?v=1574899472"},
    {name:"Sugar", img:"https://i1.wp.com/images.indianexpress.com/2020/06/GettyImages-sugar-hacks_759.jpg?ssl=1"},
    {name:"Cocoa Powder", img:"https://mk0naturalmoreikvifi.kinstacdn.com/wp-content/uploads/2020/02/cocoa-powder2.jpg"},
];


class Cost extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            variableCost: []
        }
        this.id = props.id
        this.num = 0
    }

    componentDidMount = async () => {
        await this.setState({
            variableCost: this.loadVariableCost(this.id)
        })
    }

    loadVariableCost = (id) => {
        return [...defaultVariableCost]
    }

    addIngredient = async () => {
        this.num +=1
        const newElement = {
            img: "https://image.freepik.com/free-vector/cartoon-chef-show-ok_61878-753.jpg",
            name: `empty-${this.num}`
        }
        await this.setState(prevState => ({
            variableCost: [...prevState.variableCost, newElement]
          }))
    }

    deleteIngredient = async (name) => {
        await this.setState(prevState => ({
            variableCost: [...prevState.variableCost].filter(d => d.name !== name)
          }))
    }

    render() {
        const {variableCost} = this.state;
        console.log(variableCost)
        return (
            <React.Fragment>
                 <Navbar/>
                 <VariableCost variableCost={variableCost} addIngredient={this.addIngredient} deleteIngredient={this.deleteIngredient}/>
                 <hr/>
                 <FixedCost/>
                 <hr/>
                 <TotalCost/>
                <Footbar/>
            </React.Fragment>
        )
    }
}

export default Cost;