import React from 'react';
import Navbar from '../Components/Navbar';
import Footbar from '../Components/Footbar';

class Home extends React.Component {
    constructor(props) {
        super(props)
        }

    render() {
        return (
            <React.Fragment>
                 <Navbar/>
                <div class="clearfix"></div>

                <header class="header">
                    <div class="container">
                        <div class="header_area">
                            <h1>Welcome to </h1>
                            <h1>Picnique Pastry</h1>
                            <p>Make your daily vacation's vibes with us</p>
                        </div>
                    </div>
                </header>

                <div class="clearfix"></div>

                {/* <section class="contact">
                    <div class="container">
                        <div class="contact_area">
                            <h1>Contact Us</h1>
                            <form>
                                <label>Your Name</label>
                                <input type="text" placeholder="Your Name"/>
                                <label>Your Email</label>
                                <input type="email" placeholder="Your Email"/>
                                <label>Your Subject</label>
                                <input type="text" placeholder="Your Subject">
                                <label>Your Message</label>
                                <textarea name="" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
                                <button>send</button>
                            </form>
                        </div>
                    </div>
                </section> */}
                <Footbar/>
            </React.Fragment>
        )
    }
}

export default Home;