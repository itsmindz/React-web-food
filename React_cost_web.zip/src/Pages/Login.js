import React from 'react';
import Navbar from '../Components/Navbar';
import Footbar from '../Components/Footbar';
import LoginForm from '../Components/LoginForm';

class Home extends React.Component {
    constructor(props) {
        super(props)
        }

    render() {
        return (
            <React.Fragment>
                 <Navbar/>
                <div class="clearfix"></div>

                <div style={{
                    margin: "0 auto"
                }}>
                    <LoginForm/>
                </div>

                <div class="clearfix"></div>
                <Footbar/>
            </React.Fragment>
        )
    }
}

export default Home;