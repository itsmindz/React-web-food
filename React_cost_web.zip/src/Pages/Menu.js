import React from 'react';
import Navbar from '../Components/Navbar';
import Footbar from '../Components/Footbar';
import MenuItem from '../Components/MenuItem'


const tempData = [
    {id: 1, img: "https://houseofnasheats.com/wp-content/uploads/2020/06/best-homemade-brownie-recipe-13.jpg", name: "Brownie"},
    {id: 2, img: "https://preppykitchen.com/wp-content/uploads/2020/04/red-velvet-cookies-feature-image.jpg", name: "Red Velvet Cookie"},
    {id: 3, img: "https://preppykitchen.com/wp-content/uploads/2020/06/Alfajores-Feature-3-768x1088.jpg", name: "Alfajores"},
    {id: 4, img: "https://preppykitchen.com/wp-content/uploads/2020/04/French-Macarons-feature-1200-768x1088.jpg", name: "Macaron"},
    {id: 5, img: "https://preppykitchen.com/wp-content/uploads/2018/12/Smores-cookie-cups-feature-2.jpg", name: "S’mores Cookie Cups"},
    {id: 6, img: "https://preppykitchen.com/wp-content/uploads/2020/04/cream-cheese-cookies-feature-768x1088.jpg", name: "Cream Cheese Cookies"},
    {id: 7, img: "https://preppykitchen.com/wp-content/uploads/2019/08/Peanut-butter-blossoms-feature.jpg", name: "Peanut Butter Blossoms"},
    {id: 8, img: "https://preppykitchen.com/wp-content/uploads/2019/12/chocolate-sugar-cookies-feature.jpg", name: "Chocolate Sugar Cookies"},
    {id: 9, img: "https://preppykitchen.com/wp-content/uploads/2019/08/Oreo-Balls-feature-2.jpg", name: "Oreo Balls"},
    {id: 10, img: "https://preppykitchen.com/wp-content/uploads/2019/07/Chocolate-Crinkle-Cookies-feature.jpg", name: "Chocolate Crinkle Cookies"},
]

class Home extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            data: tempData
        }
    }


    render() {
        return (
            <React.Fragment>
                <Navbar/>
                <div class="clearfix"></div>
                <div class="menu-list"
                    style={{marginTop: "10px",minHeight: "600px"}}
                >
                    {this.state.data.map( datum => <MenuItem id={datum.id} img={datum.img} name={datum.name}/>)}
                </div>
                <div class="clearfix"></div>            
                <Footbar/>
            </React.Fragment>
        )
    }
}

export default Home;