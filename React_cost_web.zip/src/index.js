import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Home from './Pages/Home.js';
import Menu from './Pages/Menu.js';
import Cost from './Pages/Cost.js';
import Login from './Pages/Login.js';
import {Router,Route,Link,browserHistory} from 'react-router';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(
  <Router history={browserHistory}>
    <Route path="/React" component={App}/>
    <Route path="/" component={Home}/>
    <Route path="/menu" component={Menu}/>
    <Route exact path="/cost/:id" component={Cost} />
    <Route path="login"component={Login}/> 
  </Router> ,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
